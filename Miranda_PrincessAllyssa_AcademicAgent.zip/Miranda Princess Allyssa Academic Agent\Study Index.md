# Study Index

Use this index to track studied lessons and the links between them. Add new entries below. Don't remove existing ones.

**Connection labels:**

- **Stated:** the lecture says it directly.
- **Agent-identified:** a link found between lessons that the source doesn't state. Confirm it when the related lesson is studied.

---

## PDC10 — Conversational AI and Prompt Engineering

### Topic I — Introduction to Conversational AI

- **Lecture file:** `01 Courses/PDC10/PDC10 2026-07-13 Introduction to Conversational AI Lecture Slides.pdf`
- **Organizational date:** 2026-07-13. This is the file's creation date, not a verified lecture date.
- **Studied:** 2026-11-01
- **Outputs:**
  - Notes: `05 Study Materials/Notes/PDC10 2026-07-13 Introduction to Conversational AI Notes.md` (and `.docx`)
  - Questions: `05 Study Materials/Review Questions/PDC10 2026-07-13 Introduction to Conversational AI Review Questions.md`
  - Answers: `05 Study Materials/Answer Keys/PDC10 2026-07-13 Introduction to Conversational AI Answer Key.md`
- **Key concepts:**
  - conversational AI
  - chatbots vs. virtual assistants
  - generative AI
  - large language models (LLMs)
  - tokens and next-token prediction
  - probabilistic outputs
  - traditional vs. modern conversational AI
  - evolution timeline (ELIZA → transformers → LLMs → agentic systems)
  - capabilities
  - limitations (hallucination, prompt sensitivity, and others)
  - risks and responsible use
  - conversational AI ecosystem
  - basic architecture and feedback loop
  - high-risk use cases
- **Prerequisites:** none stated in the source. This is the first course topic.
- **Follow-up topics:**
  - **Prompt Engineering Fundamentals** — *Stated* (p.17: "Next topic"). Course file: `PDC10 2026-08-11 Prompt Engineering Fundamentals Lecture Slides.pdf`. Not yet studied.
- **Related concepts:**
  - **Prompt sensitivity** (p.10) and the **prompt engineering portfolio** (p.2) → Prompt Engineering Fundamentals — *Stated* in this lecture.
  - **Tool-using and agentic systems** (p.5) → *PDC10 2026-10-26 Agentic AI in IT and Business Student Notes.pptx* — *Agent-identified*. Not yet studied, so confirm when it is.
  - **AI assistant project** (p.2, MCO link) — *Stated*. No project file is in the workspace yet.
