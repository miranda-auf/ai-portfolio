# PDC10 — Introduction to Conversational AI: Review Questions

> **Source lecture:** `PDC10 2026-07-13 Introduction to Conversational AI Lecture Slides.pdf`
> **Format:** 10 questions: 4 recall, 3 application, 3 analysis. Answer them on your own first, then check against the separate answer key: `05 Study Materials/Answer Keys/PDC10 2026-07-13 Introduction to Conversational AI Answer Key.md`.

---

## Part A — Recall

**Q1.** How does the lecture define *conversational AI*?

**Q2.** What is a large language model (LLM), and what does it predict when it generates a response?

**Q3.** Name **four** limitations of conversational AI listed in the lecture.

**Q4.** List, in order, the components of the basic conversational AI architecture from the user to the response. Also name what the feedback loop contains.

---

## Part B — Application

**Q5.** A university enrollment bot answers questions only by offering a fixed menu of options written in advance. A student types a question that isn't on the menu.
(a) Is this a traditional chatbot or modern conversational AI?
(b) Based on the lecture, what is likely to happen?

**Q6.** A student prompts an LLM: "Explain photosynthesis to Grade 8 students." The answer is clear and fluent but contains one incorrect fact.
(a) Using the lecture's explanation of how LLMs produce responses, explain why this can happen.
(b) What should the student do before using the answer?

**Q7.** A company plans an internal HR assistant that summarizes policy documents and helps employees find procedures. Identify **two** risks from the lecture that apply, and recommend **one** safeguard taken from the lecture's architecture or examples.

---

## Part C — Analysis

**Q8.** The lecture states that "a conversational AI system is more than one model." Analyze why a retrieval system and guardrails/safety filters are needed alongside the LLM. Connect your answer to at least two LLM limitations from the lecture.

**Q9.** Using the lecture's criteria for evaluating use cases, compare a **customer service** assistant with a **healthcare information support** assistant (both listed as industry use cases). Which one needs stronger controls, and why?

**Q10.** The lecture says that LLMs produce *probabilistic outputs* and that "capability does not remove the need for quality control." Analyze how these two statements together support the lecture's formula for responsible use.
