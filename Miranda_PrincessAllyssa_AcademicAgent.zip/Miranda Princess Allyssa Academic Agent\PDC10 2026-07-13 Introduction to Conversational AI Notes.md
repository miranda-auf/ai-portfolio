# PDC10 — Introduction to Conversational AI: Study Notes

> **Source:** `PDC10 2026-07-13 Introduction to Conversational AI Lecture Slides.pdf` (19 pages). Page references (p.) match the PDF page numbers, which are the same as the slide numbers printed on the slides.
> **Labels:** Unlabeled content is stated in the lecture. Text marked **Agent Explanation** is extra clarification that is *not* in the lecture.

---

## 1. Lesson identification

| Item | Detail | Source |
|---|---|---|
| Course | PDC10 — Conversational AI and Prompt Engineering | p.1 (course title); course code confirmed by the user |
| Lesson | Topic I: Introduction to Conversational AI | p.1 |
| Instructor | Dr. Adriane Brent S. Castro | p.1 |
| File date | 2026-07-13: the file's creation date, used for organizing only. It is **not a verified lecture date** | File metadata |
| Course alignment | CLO 1: Explain principles, architectures, capabilities, limitations, and risks of conversational AI and large language models | p.2 |
| MCO link | These concepts support both the AI assistant project and the prompt engineering portfolio | p.2 |
| Next topic | Prompt Engineering Fundamentals | p.17 |
| Assignment | "Introduction to Conversational AI Essay": four questions, 10 points each. **No due date is stated in the source** | p.18 |

## 2. Learning objectives

By the end of the lesson, you should be able to (p.2):

1. Define conversational AI.
2. Explain how AI systems work.
3. Identify the AI ecosystem.
4. Describe the role of LLMs.
5. Recognize capabilities, limitations, and risks.

## 3. Key concepts and definitions

| Term | Definition (as stated) | Source |
|---|---|---|
| **Conversational AI** | Enables computers to understand, process, and respond to human language through text or voice | p.4 |
| **Chatbots** | Often task-specific systems used for FAQs, support, or guided flows | p.4 |
| **Virtual assistants** | Broader assistants that may use voice, apps, reminders, or device control | p.4 |
| **Generative AI** | AI that can create new text, images, audio, code, or other content | p.4 |
| **Large language model (LLM)** | A model trained on large collections of text to learn patterns and relationships in language. LLMs are also described as models trained to generate and transform language using token patterns | p.7, p.4 |
| **Hallucination** | The system may generate incorrect or unsupported claims | p.10 |
| **Conversational AI ecosystem** | More than one model: an ecosystem of people, interfaces, data, tools, controls, and feedback | p.12 |
| **Responsible use** | Useful output + appropriate safeguards + accountable humans | p.11 |

**Key facts about LLMs (p.7):**

- They are trained on large collections of text.
- They learn language patterns and relationships.
- They predict likely sequences of tokens.
- They do not think or understand exactly like a human.
- They can produce fluent but inaccurate information.
- The lecture's analogy: an LLM is "like a highly advanced language prediction system". It estimates what text is likely to come next based on the prompt, prior context, and learned patterns.

> **Agent Explanation:** A *token* is a small unit of text that the model processes, such as a word, part of a word, or punctuation mark. The lecture uses the term but doesn't define it.

### Traditional chatbots vs. modern conversational AI (p.6)

| Dimension | Traditional chatbots | Modern conversational AI |
|---|---|---|
| Response generation | Rules, menus, scripts, keywords | Generates or composes language from context |
| Flexibility | Limited to expected paths | Handles a wider variety of requests |
| Context awareness | Usually short or session-based | Can use conversation history and system context |
| Knowledge coverage | Narrow domain content | Broad language ability; may use retrieval or tools |
| Personalization | Mostly fixed user flows | Can adapt tone, examples, and task style |
| Limitations | Breaks when users go off-script | May hallucinate or sound correct when wrong |
| Typical applications | FAQs, booking, ticket routing | Tutoring, drafting, analysis, support, decision assistance |

### Evolution of conversational AI (p.5)

The lecture frames the history as a move "from scripted responses to language models, retrieval, tools, and agent-like workflows":

| Period | Milestone |
|---|---|
| 1960s | ELIZA (rule-based) |
| 1990s | Pattern matching |
| 2000s | NLP systems |
| 2010s | ML assistants (Siri / Alexa) |
| 2017 | Transformer models |
| 2020s | LLMs and Copilots |
| Today | Tool-using and agentic systems |

The lecture notes that the examples are provided for illustration only and are not endorsements (p.5).

## 4. Processes or procedures

### 4.1 How an LLM produces a response (p.8)

1. The user submits a prompt.
2. The prompt is divided into tokens.
3. The model analyzes patterns and context.
4. The model predicts the next likely token.
5. Tokens continue until a response is formed.
6. Instructions, safety rules, tools, or external information may influence the output.

**Important clarification (p.8):** LLMs generate *probabilistic* outputs. They are not simply retrieving a guaranteed correct answer from a database. Some systems may use retrieval or tools, but the generated response still needs verification.

The simplified flow on p.7 is: User → Prompt → Token Processing → Language Model → Generated Response.

### 4.2 Basic conversational AI architecture (p.13)

Flow: **User → Interface → Input Processing → LLM → Retrieval or Tools → Safety & Validation → Response**, with a **feedback loop** made of user ratings, corrections, logs, evaluation results, and improvement actions.

| Component | Role | Source |
|---|---|---|
| Interface | Where users type, speak, upload, or receive output | p.13 |
| Input processing | Cleans, structures, routes, or enriches the user request | p.13 |
| LLM | Generates or transforms language based on context | p.13 |
| Retrieval/tools | Adds approved external information or capabilities | p.13 |
| Safety/validation | Checks privacy, policy, format, risk, and quality | p.13 |
| Feedback | Improves future design, prompts, data, and evaluation | p.13 |

### 4.3 Ecosystem components (p.12)

The ecosystem diagram lists these components: user, prompt/input, interface, system instructions, large language model, conversation history, retrieval system, knowledge base/database, external tools/APIs, guardrails and safety filters, output validation, and evaluation and feedback.

> **Agent Explanation:** The architecture on p.13 shows the *order* in which a request travels. The ecosystem on p.12 shows *everything the system depends on*, including parts that aren't steps in the flow, such as system instructions, conversation history, and the knowledge base.

### 4.4 Classroom activity: AI ecosystem mapping (p.15)

Group task: map one conversational AI application from user input to safe output.

1. Form small groups.
2. Select one conversational AI application.
3. Identify the intended users.
4. Identify the inputs and expected outputs.
5. List the required AI ecosystem components.
6. Identify two possible risks.
7. Recommend one safety, privacy, or validation mechanism.

Timing is 10–15 minutes of group work and 2 minutes per group to present. The output is one simple map showing users, inputs, model, data/tools, risks, safeguards, and expected response.

## 5. Examples from the lecture

- **Everyday AI (p.3):** chatbots (course, bank, telco support); search assistants (AI summaries and suggestions); voice assistants (phone, speaker, car); recommendation systems (videos, products, music); AI writing tools (drafting, grammar, ideas); automated support (tickets and FAQs).
- **Photosynthesis prompt (p.8):** For "Explain photosynthesis to Grade 8 students", the model *does not open a biology textbook by default*. It predicts a likely explanation from training patterns and the prompt context.
- **Capabilities (p.9):** question answering, content generation, summarization, translation, brainstorming, tutoring, coding assistance, customer support, information extraction, and decision support.
  - *Academic example:* A virtual learning assistant explains a programming concept, gives practice questions, and suggests resources. The teacher still verifies correctness and appropriateness.
  - *Organizational example:* An internal assistant summarizes policy documents, drafts reports, and helps employees locate procedures. Access control and data privacy matter.
  - *Industry example:* A customer support assistant answers product questions, routes issues, and extracts details from complaints. Complex cases need escalation to humans.
- **Use cases (p.14):**
  - *Academic:* virtual learning assistants, research support, student advising, automated feedback.
  - *Organizational:* human resources assistants, internal knowledge assistants, report generation, employee support.
  - *Industry:* customer service, healthcare information support, banking assistance, e-commerce recommendations, software development support.

## 6. Agent explanations (clearly labeled)

> **Agent Explanation — why "probabilistic" matters:** Because the model picks *likely* next tokens instead of looking up a stored answer, the same prompt can produce different wording, and a confident-sounding sentence can still be wrong. This links the generation process on p.8 to the "Inconsistency" and "Hallucinations" limitations on p.10.

> **Agent Explanation — chatbot vs. LLM in one line:** A traditional chatbot *selects* from responses written in advance. An LLM-based assistant *composes* a new response each time.

> **Agent Explanation — retrieval vs. training:** Retrieval brings in information when a request is made, for example from a knowledge base, so the answer can reflect current or organization-specific content. This is one way to address the "outdated knowledge" limitation (p.10). The lecture stresses that retrieved responses still need verification (p.8).

## 7. Connections to earlier lessons

- **Earlier lessons:** none. This is Topic I and the first lesson recorded in the Study Index. The lecture states no prerequisites.
- **Next lesson (stated in source):** Prompt Engineering Fundamentals (p.17). The lecture explains *prompt sensitivity*, meaning small wording changes can change the response (p.10). It also links these concepts to the prompt engineering portfolio (p.2).
- **Related course file (agent-identified, not stated in this lecture):** p.5 names "Tool-using & agentic systems" as the current stage. The course folder also contains *PDC10 2026-10-26 Agentic AI in IT and Business Student Notes.pptx*. Confirm this connection when that lesson is studied.

## 8. Common misconceptions or cautions

| Misconception | What the lecture says | Source |
|---|---|---|
| "An LLM looks up the correct answer in a database." | LLMs generate probabilistic outputs. They are not simply retrieving a guaranteed correct answer | p.8 |
| "If it sounds fluent, it's correct." | Fluent responses are not always factual responses | p.10 |
| "Using retrieval or tools makes the answer guaranteed." | The generated response still needs verification | p.8 |
| "The AI understands like a person." | It does not think or understand exactly like a human, and has no genuine human understanding | p.7, p.10 |
| "Conversational AI is just the model." | A conversational AI system is more than one model. It is an ecosystem | p.12 |
| "A capable system doesn't need checking." | Capability does not remove the need for quality control | p.9 |
| "Asking the same question gives the same answer." | The same question may produce different phrasing or conclusions | p.10 |

**Limitations (p.10):** hallucinations, outdated knowledge, prompt sensitivity, reasoning limits, no genuine human understanding, inconsistency, ambiguity handling, and data dependence.

**Risks (p.11):**

- privacy risks
- bias and discrimination
- misinformation
- security concerns (prompts, tools, and data access can create attack surfaces)
- overreliance
- academic integrity
- transparency gaps
- intellectual property

**Cautions:**

- Human judgment and verification remain necessary (p.11).
- High-risk applications require stronger controls, testing, documentation, and human oversight (p.14).
- Judge examples by purpose, users, data sensitivity, potential harm, and required accuracy (p.14).
- For the assignment: verify any claims, and don't submit AI-generated text without review, citation where appropriate, and compliance with class policy (p.18).

## 9. Quick review summary

Key takeaways (p.17):

- **Human-like interaction:** Conversational AI enables interaction through text or voice.
- **LLM foundation:** LLMs generate language by predicting likely token sequences.
- **Ecosystem view:** Systems include models, interfaces, data, tools, retrieval, guardrails, and evaluation.
- **Power and limits:** AI can be useful but may be inaccurate, biased, unsafe, or privacy-sensitive.
- **Responsible design:** Use oversight, validation, transparency, privacy protection, and continuous evaluation.

**Knowledge check from the lecture (p.16):**

1. What is conversational AI?
2. How is a traditional chatbot different from an LLM-based assistant?
3. How does an LLM generate a response?
4. What are three components of a conversational AI ecosystem?
5. Why should users verify AI-generated information?

## 10. Source list

**Primary source used for these notes:**

- `01 Courses/PDC10/PDC10 2026-07-13 Introduction to Conversational AI Lecture Slides.pdf`, pages 1–19.

**References listed in the lecture (p.19).** These were not consulted for these notes.

- Russell, S., & Norvig, P. *Artificial Intelligence: A Modern Approach*, 4th ed. Pearson, 2021.
- Jurafsky, D., & Martin, J. *Speech and Language Processing*, 3rd ed. draft.
- Vaswani, A., et al. "Attention Is All You Need." *Advances in Neural Information Processing Systems*, 2017.
- Brown, T. B., et al. "Language Models are Few-Shot Learners." *Advances in Neural Information Processing Systems*, 2020.
- OpenAI. Prompt engineering and model behavior documentation.
- Anthropic. Prompt engineering and context engineering documentation.
- Google. AI Principles and Responsible AI resources.
- Microsoft. Responsible AI Standard and Azure Responsible AI documentation.
