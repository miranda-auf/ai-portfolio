# PDC10 — Introduction to Conversational AI: Answer Key

> **Source lecture:** `PDC10 2026-07-13 Introduction to Conversational AI Lecture Slides.pdf` (p. = PDF page = printed slide number)
> **Questions file:** `05 Study Materials/Review Questions/PDC10 2026-07-13 Introduction to Conversational AI Review Questions.md`
> **Labels:** Unlabeled answer content is stated in the lecture. **Agent Explanation** marks reasoning the lecture does not state directly.
> **Verification:** Every answer was checked against the cited pages. No item is SOURCE UNCERTAIN. Q6(a), Q8, Q9 and Q10 contain labeled Agent Explanation.

---

## Part A — Recall

### Q1. Definition of conversational AI
**Answer:** Conversational AI enables computers to understand, process, and respond to human language through text or voice.
**Source:** p.4 (also p.17: "Conversational AI enables interaction through text or voice").
**Verification:** Verified. This is the lecture's exact wording.

### Q2. What an LLM is and what it predicts
**Answer:** An LLM is a model trained on large collections of text to learn patterns and relationships in language. When generating, it **predicts the next likely token**, and tokens continue until a response is formed. In the lecture's words, it predicts likely sequences of tokens.
**Source:** p.7 (definition and key ideas), p.8 (steps 4–5), p.17 ("LLMs generate language by predicting likely token sequences").
**Verification:** Verified.

### Q3. Four limitations
**Answer:** Any four of these eight:

- hallucinations
- outdated knowledge
- prompt sensitivity
- reasoning limits
- no genuine human understanding
- inconsistency
- ambiguity handling
- data dependence

**Source:** p.10.
**Verification:** Verified. All eight are listed on p.10.

### Q4. Architecture order and feedback loop
**Answer:**

- **Order:** User → Interface → Input Processing → LLM → Retrieval or Tools → Safety & Validation → Response.
- **Feedback loop:** user ratings, corrections, logs, evaluation results, and improvement actions.

**Source:** p.13.
**Verification:** Verified against both the diagram and the text on p.13.

---

## Part B — Application

### Q5. Enrollment menu bot
**Answer:**
(a) A **traditional chatbot**. It generates responses from rules, menus, scripts, and keywords, and follows mostly fixed user flows.
(b) It is likely to **fail or give an unhelpful response**. Traditional chatbots are limited to expected paths and *break when users go off-script*.

**Source:** p.6 (comparison table: Response generation, Flexibility, Personalization, Limitations); p.4 (chatbots are often task-specific systems for FAQs, support, or guided flows).
**Verification:** Verified.

### Q6. Fluent but incorrect photosynthesis answer
**Answer:**
(a) LLMs generate **probabilistic outputs**. They predict likely tokens from training patterns and the prompt context. They are not retrieving a guaranteed correct answer from a database. In this exact example, the lecture says the model *does not open a biology textbook by default*. LLMs can produce *fluent but inaccurate information*, and *fluent responses are not always factual responses*. The lecture calls this kind of error a **hallucination**: incorrect or unsupported claims.
(b) The student should **verify** the content against reliable sources before using it. The lecture says the generated response still needs verification and that human judgment and verification remain necessary.

**Source:** p.8 (probabilistic outputs, photosynthesis example), p.7 (fluent but inaccurate), p.10 (hallucinations; fluent ≠ factual), p.11 (human judgment and verification).
**Agent Explanation:** "Check against a reliable source such as a textbook" is a practical way to carry out the lecture's instruction to verify. The lecture doesn't name a specific source for this example.
**Verification:** Verified. The practical tip is labeled.

### Q7. Internal HR policy assistant
**Answer:**

- **Risks (any two):**
  - **Privacy risks:** sensitive data may be exposed or reused improperly.
  - **Security concerns:** prompts, tools, and data access can create attack surfaces.
  - **Misinformation:** incorrect content can spread quickly when unchecked.
  - **Overreliance:** users may accept outputs without professional judgment.
- **Safeguard (any one):**
  - **Access control and data privacy** protections. The lecture's organizational example of an internal assistant that summarizes policy documents says "access control and data privacy matter."
  - A **safety/validation** component that checks privacy, policy, format, risk, and quality.
  - **Human verification** of outputs.

**Source:** p.11 (risks), p.9 (organizational example), p.13 (safety/validation), p.14 (HR assistants and internal knowledge assistants listed as organizational use cases).
**Verification:** Verified.

---

## Part C — Analysis

### Q8. Why retrieval and guardrails are needed alongside the LLM
**Answer (stated in the lecture):**

- A conversational AI system is an ecosystem of people, interfaces, data, tools, controls, and feedback. The retrieval system, knowledge base, guardrails and safety filters, and output validation are listed as separate components (p.12).
- **Retrieval/tools** add approved external information or capabilities (p.13).
- **Safety/validation** checks privacy, policy, format, risk, and quality (p.13).
- The LLM alone has limitations, including **outdated knowledge** (some systems may not know recent changes unless connected to current sources) and **hallucinations** (p.10).
- Responses produced with retrieval still need verification (p.8).

**Agent Explanation (the analysis):**

- Retrieval addresses *outdated knowledge* and narrow organizational content by supplying current, approved information at the time of the request.
- Guardrails and validation address *hallucinations*, privacy and policy risks by checking the output before it reaches the user.
- Neither fully removes the risk. That's why the lecture still requires human verification.

**Verification:** The component roles and limitations are verified on p.8, p.10, p.12 and p.13. The step that links each component to the limitation it addresses is Agent Explanation.

### Q9. Customer service vs. healthcare information support
**Answer (stated in the lecture):**

- Both appear as industry use cases (p.14).
- Use cases should be evaluated by **purpose, users, data sensitivity, potential harm, and required accuracy** (p.14).
- **High-risk applications require stronger controls, testing, documentation, and human oversight** (p.14).
- In the industry example on p.9, complex customer-support cases need escalation to humans.

**Agent Explanation (the analysis):** Applying the p.14 criteria, healthcare information support is likely to involve more sensitive data, greater potential harm if wrong, and a higher required level of accuracy than routine customer service. By those criteria it would need the stronger controls, testing, documentation, and human oversight the lecture prescribes for high-risk applications. Customer service still needs safeguards, such as escalating complex cases to humans (p.9).
**Caution:** The lecture **does not explicitly classify** healthcare information support as high-risk. That classification is the student's or agent's reasoning, applied with the lecture's criteria.
**Verification:** The criteria and the high-risk rule are verified on p.14. The comparison itself is Agent Explanation.

### Q10. Probabilistic outputs, quality control and responsible use
**Answer (stated in the lecture):**

- LLMs generate probabilistic outputs, not guaranteed correct answers (p.8).
- The same question may produce different phrasing or conclusions (p.10).
- Capability does not remove the need for quality control (p.9).
- The responsible-use formula is: **useful output + appropriate safeguards + accountable humans** (p.11).
- Responsible design uses oversight, validation, transparency, privacy protection, and continuous evaluation (p.17).

**Agent Explanation (the analysis):**

- Because outputs are probabilistic, a system's capability alone can't guarantee a correct answer every time. That explains why "useful output" is only one of the three parts of the formula.
- *Safeguards* (validation, guardrails) catch errors systematically.
- *Accountable humans* make the final judgment and take responsibility for the result.
- So the two statements explain *why* the formula needs all three parts.

**Verification:** All quoted statements are verified on p.8, p.9, p.10, p.11 and p.17. The step that explains why the formula needs all three parts is Agent Explanation.
